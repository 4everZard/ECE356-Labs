-- for part a and b
CREATE INDEX rev_count ON user (review_count);
